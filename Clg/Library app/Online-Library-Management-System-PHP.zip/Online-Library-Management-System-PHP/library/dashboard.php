<?php
session_start();
error_reporting(0);
include('includes/config.php');

if(strlen($_SESSION['login']) == 0){
    header('location:index.php');
    exit;
}
?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>User Dashboard | Online Library</title>

    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <link href="assets/css/style.css" rel="stylesheet" />
</head>
<body>

<?php include('includes/header.php'); ?>

<div class="content-wrapper">
<div class="container">

<!-- DASHBOARD TITLE -->
<div class="row pad-botm">
    <div class="col-md-12">
        <h4 class="header-line">User Dashboard</h4>
    </div>
</div>

<div class="row">

<!-- BOOK COUNT -->
<a href="listed-books.php">
<div class="col-md-4 col-sm-6">
    <div class="alert alert-success text-center">
        <i class="fa fa-book fa-4x"></i>
        <?php
        $sql = "SELECT id FROM tblbooks";
        $query = $dbh->prepare($sql);
        $query->execute();
        ?>
        <h3><?php echo $query->rowCount(); ?></h3>
        Books Listed
    </div>
</div>
</a>

<!-- NOT RETURNED -->
<div class="col-md-4 col-sm-6">
    <div class="alert alert-warning text-center">
        <i class="fa fa-recycle fa-4x"></i>
        <?php
        $sid = $_SESSION['stdid'];
        $sql = "SELECT id FROM tblissuedbookdetails 
                WHERE StudentID=:sid AND (RetrunStatus IS NULL OR RetrunStatus=0)";
        $query = $dbh->prepare($sql);
        $query->bindParam(':sid',$sid,PDO::PARAM_STR);
        $query->execute();
        ?>
        <h3><?php echo $query->rowCount(); ?></h3>
        Books Not Returned
    </div>
</div>

<!-- ISSUED -->
<a href="issued-books.php">
<div class="col-md-4 col-sm-6">
    <div class="alert alert-success text-center">
        <i class="fa fa-book fa-4x"></i>
        <?php
        $sql = "SELECT id FROM tblissuedbookdetails WHERE StudentID=:sid";
        $query = $dbh->prepare($sql);
        $query->bindParam(':sid',$sid,PDO::PARAM_STR);
        $query->execute();
        ?>
        <h3><?php echo $query->rowCount(); ?></h3>
        Total Issued Books
    </div>
</div>
</a>

<!-- PAPERS -->
<a href="papers.php">
<div class="col-md-4 col-sm-6">
    <div class="alert alert-info text-center">
        <i class="fa fa-file-pdf-o fa-4x"></i>
        <h3>Papers</h3>
        View Research Papers
    </div>
</div>
</a>

</div>

<!-- ================= SMART BOOK RECOMMENDATIONS ================= -->

<div class="row pad-botm">
    <div class="col-md-12">
        <h4 class="header-line">📚 Smart Book Recommendations</h4>
    </div>
</div>

<?php
$sid = $_SESSION['stdid'];
$shownBooks = [];
?>

<div class="row">

<!-- ================= 1️⃣ LAST ISSUED BOOK ================= -->
<div class="col-md-4">
    <h5>📘 Based on Your Last Issued Book</h5>

    <?php
    $sql = "SELECT BookId FROM tblissuedbookdetails 
            WHERE StudentID = :sid 
            ORDER BY id DESC LIMIT 1";
    $q = $dbh->prepare($sql);
    $q->bindParam(':sid', $sid);
    $q->execute();

    if ($q->rowCount()) {

        $lastBook = $q->fetch(PDO::FETCH_OBJ)->BookId;

        $q2 = $dbh->prepare("SELECT CatId FROM tblbooks WHERE id = :id");
        $q2->bindParam(':id', $lastBook);
        $q2->execute();
        $catId = $q2->fetch(PDO::FETCH_OBJ)->CatId;

        $q3 = $dbh->prepare("
            SELECT * FROM tblbooks 
            WHERE CatId = :cat AND id != :bid 
            LIMIT 1
        ");
        $q3->bindParam(':cat', $catId);
        $q3->bindParam(':bid', $lastBook);
        $q3->execute();

        foreach ($q3->fetchAll(PDO::FETCH_OBJ) as $b) {
            $shownBooks[] = $b->id;
    ?>
        <div class="alert alert-info text-center" style="height:220px;">
            <i class="fa fa-book fa-3x"></i>
            <h4><?= htmlentities($b->BookName) ?></h4>
            <small>Similar category</small>
        </div>
    <?php
        }
    } else {
        echo "<p class='text-muted'>No history yet</p>";
    }
    ?>
</div>


<!-- ================= 2️⃣ FAVORITE CATEGORY ================= -->
<div class="col-md-4">
    <h5>📗 Your Favorite Category</h5>

    <?php
    $sql = "
        SELECT b.CatId, COUNT(*) AS total
        FROM tblissuedbookdetails i
        JOIN tblbooks b ON i.BookId = b.id
        WHERE i.StudentID = :sid
        GROUP BY b.CatId
        ORDER BY total DESC
        LIMIT 1
    ";
    $q = $dbh->prepare($sql);
    $q->bindParam(':sid', $sid);
    $q->execute();

    if ($q->rowCount()) {

        $favCat = $q->fetch(PDO::FETCH_OBJ)->CatId;

        $q2 = $dbh->prepare("
            SELECT * FROM tblbooks 
            WHERE CatId = :cat 
            AND id NOT IN (" . implode(',', $shownBooks ?: [0]) . ")
            LIMIT 1
        ");
        $q2->bindParam(':cat', $favCat);
        $q2->execute();

        foreach ($q2->fetchAll(PDO::FETCH_OBJ) as $b) {
            $shownBooks[] = $b->id;
    ?>
        <div class="alert alert-success text-center" style="height:220px;">
            <i class="fa fa-heart fa-3x"></i>
            <h4><?= htmlentities($b->BookName) ?></h4>
            <small>Your preferred category</small>
        </div>
    <?php
        }
    } else {
        echo "<p class='text-muted'>No preference yet</p>";
    }
    ?>
</div>


<!-- ================= 3️⃣ MOST POPULAR ================= -->
<div class="col-md-4">
    <h5>🔥 Most Popular Books</h5>

    <?php
    $sql = "
        SELECT b.id, b.BookName, COUNT(i.BookId) AS total
        FROM tblissuedbookdetails i
        JOIN tblbooks b ON i.BookId = b.id
        GROUP BY i.BookId
        ORDER BY total DESC
        LIMIT 1
    ";
    $q = $dbh->prepare($sql);
    $q->execute();

    foreach ($q->fetchAll(PDO::FETCH_OBJ) as $b) {
        if (in_array($b->id, $shownBooks)) continue;
    ?>
        <div class="alert alert-warning text-center" style="height:220px;">
            <i class="fa fa-fire fa-3x"></i>
            <h4><?= htmlentities($b->BookName) ?></h4>
            <small>Issued <?= $b->total ?> times</small><br><br>
            <a href="listed-books.php?popular=1" class="btn btn-warning btn-sm">
                View
            </a>
        </div>
    <?php } ?>
</div>

</div>

<!-- ================= TOP RATED BOOKS ================= -->

<hr>

<div class="row">
    <div class="col-md-12">
        <h5>⭐ Top Rated Books</h5>
    </div>

<?php
$sql = "
    SELECT b.BookName, ROUND(AVG(r.Rating),1) AS avg_rating
    FROM tblbookratings r
    JOIN tblbooks b ON r.BookId = b.id
    GROUP BY r.BookId
    ORDER BY avg_rating DESC
    LIMIT 4
";
$q = $dbh->prepare($sql);
$q->execute();

foreach ($q->fetchAll(PDO::FETCH_OBJ) as $row) {
?>
    <div class="col-md-3">
        <div class="alert alert-success text-center">
            <i class="fa fa-star fa-2x"></i>
            <h4><?= $row->BookName ?></h4>
            <p>⭐ <?= $row->avg_rating ?>/5</p>
        </div>
    </div>
<?php } ?>
</div>
